# Copyright 2013 Chris Johns (chrisj@rtems.org)
# 
# This file's license is 2-clause BSD as in this distribution's LICENSE.2 file.
#

__all__ = ['rtems', 'pkgconfig']
